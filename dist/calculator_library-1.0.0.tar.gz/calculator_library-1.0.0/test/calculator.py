class Calculator:

    def add(self,a:int ,b:int):
        print(f"The sum of Given Two number is {a+b}")



